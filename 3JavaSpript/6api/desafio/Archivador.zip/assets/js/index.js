async function conexionApi(currency) {
    try {
        const newLocal = "https://mindicador.cl/api/";
        const res = await fetch(newLocal + currency);
        const data = await res.json();
        return data;
    } catch (e) {
    alert("NO se logra conectar a la a mindicador.cl");
    }
}


let btn_search = document.querySelector("#btn_buscar");
let result = document.querySelector('#resultado');

btn_search.addEventListener("click", async ()  =>  {
    const clpMonto = parseFloat(document.querySelector("#clpMonto").value);
    const currency = document.querySelector("#selector_moneda").value;

    let resultado = await conexionApi(currency);
    let valorMoneda = parseFloat(resultado.serie[0].valor);
    let calculo = clpMonto/valorMoneda;


    result.innerHTML = 'Resultado: ' + calculo;

    var xmlhttp = new XMLHttpRequest();
    var url = "https://mindicador.cl/api/" + currency;
    xmlhttp.open("GET",url,true);
    xmlhttp.send();
    xmlhttp.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200){
        //     var data = JSON.parse(this.responseText);
        // //     let data;
        // //    for(var i=0; i <= 10; i++){
        //     data[i] = resultado;
        //    }
        //   console.log(data);
            let data = "";
        for(var i=0; i <= 10; i++){
            data[i] = resultado.serie[i];
            console.log(data[i]);
          }
            date = resultado.serie.map(function(elem){
                return elem.fecha;
            })
            population = resultado.serie.map(function(elem){
                return elem.valor;
            })

            const ctx = document.getElementById('grafica').getContext('2d');
            const myChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: date,
                    datasets: [{
                        label: currency,
                        data: population,
                        backgroundColor: "#fff"

                    }]
                },
                options: {
                    scales: {
                        xAxes: [

                            {
                              // aqui controlas la cantidad de elementos en el eje horizontal con autoSkip
                              showXLabels: 10,

                                ticks: {
                       
                                  
                                    maxTicksLimit: 6
                                }
                            }
                          ],
                        y: {

                            beginAtZero: true
                        }
                    }
                }
            });
        }

    }




})
