
a=2;
b=3;

suma = (a, b) => a + b; 