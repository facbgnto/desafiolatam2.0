a=2;
b=3;
c=4;
suma = function sumastres(a, b, c){
    return a+b+c;
    }