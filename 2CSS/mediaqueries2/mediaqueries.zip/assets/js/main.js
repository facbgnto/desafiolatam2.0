function myFunction() {
    var x = document.getElementById("menu-burger");
    if (x.style.display === "block") {
        x.style.display = "none";
    } else {
        x.style.display = "block";
    }
}